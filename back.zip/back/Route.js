const express = require("express")
const router = express.Router()
const{SaveMsg} = require("./Controller")
router.post("/msg", SaveMsg)

module.exports = router