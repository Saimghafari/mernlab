const User = require("./model")

const SaveMsg = async (req,res)=> {
    try{
        const{name,email,message}= req.body;
        const user = User({
            name,email,message
        })
        const result = await user.save();
        res.status(200).send(result)

    }
    catch{
        res.status(400).send(err.message)
    }
}

const getData = async(req,res)=> {
    try {
        const result = await User.find();
        res.status(200).send(result)
    } catch (error) {
        res.status(400).send(err.message)
    }
}

module.exports = {SaveMsg, getData}