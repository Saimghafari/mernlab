const mongoose = require("mongoose");
const con = mongoose.connect(
    "mongodb://localhost:27017"

).then(()=> {
    console.log("Succesfully connected");
    
}).catch((err)=> {
    console.log(err.message);
    
});

module.exports = con;