const express = require("express")
const app = express()
const port  = 3000
const con = require("./connect")
const cors = require("cors")

const message = require("./Route")
app.use(express.json())

con

app.use(cors())

app.use("/api", message)

app.listen(port, function () {
    console.log(`your runing is at http://localhost:${port}`);
    
})